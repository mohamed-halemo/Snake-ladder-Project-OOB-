#pragma once

#include "GameObject.h"
#include "Player.h"

// Base Class of All Types of Cards (DecWalletCard_1, ...etc.)
// Note: We will make each type of Card in a separate class because:
// it may have additional data members and functions like: Apply(), ...etc. which have different implementation depending on Card type
class Card : public GameObject
{
protected:
	int cardNumber; // an integer representing the card number
	int Wallet;
	int ObjNum;
	bool EvenOrOdd;
	bool IsBought;
	Player* Owner;
	int CityPrice;
public:
	Card(const CellPosition & pos); // A Constructor for card that takes the cell position of it
virtual	void SetEvenOrOdd(bool);
	virtual bool GetEvenOrOdd();
	void SetCardNumber(int cnum);   // The setter of card number
	int GetCardNumber();            // The getter of card number
	virtual void SetWallet(int);
	virtual int GetWallet();
	virtual	void SetObjectNum(int);
	virtual int GetObjNum();
	void Draw(Output* pOut) const;  // Draws the card number in the cell position of the card
	virtual bool GetIsBought();// It has the same implementation for all Card Types (Non-Virtual)
	virtual void SetIsBought(bool);
	virtual Player* GetIsOwner();
	virtual void SetIsOwner(Player*);
	virtual void SetCityPrice(int);
	virtual int GetCityPrice();
	virtual void ReadCardParameters(Grid * pGrid); // It reads the parameters specific for each Card Type
	                                               // It is a virtual function (implementation depends on Card Type)

	virtual void Apply(Grid* pGrid, Player* pPlayer);  // It applies the effect of the Card Type on the passed player
	                                                   // It is a virtual function (implementation depends on Card Type)

	///void Save(ofstream& OutFile, TYPE CARD);
	///virtual void Read(ifstream& Infile) = 0;
	// It is a virtual function (implementation depends on Card Type)
	virtual bool Validate();
	virtual void Edit(Grid* pGrid);
	virtual void CopyCard(Grid* pGrid);
	virtual void CutCard(Grid* pGrid);
	virtual void PasteCard(Grid* pGrid);
	virtual ~Card(); // A Virtual Destructor
};

