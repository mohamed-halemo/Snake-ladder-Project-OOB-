#pragma once
#include "Action.h"
#include"Card.h"
#include"CellPosition.h"
class CutCardOrCoin :public Action
{
	Card* Cut;
	Cell* pCell;
	CellPosition Obj;
public:
	CutCardOrCoin(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~CutCardOrCoin();


};

