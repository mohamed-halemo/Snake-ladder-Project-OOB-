#include "SaveGrid.h"
SaveGrid::SaveGrid(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

SaveGrid::~SaveGrid()
{
}

void SaveGrid::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();









	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void SaveGrid::Execute()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	pOut->PrintMessage("Would you like to Save Grid?y/n");
	string Answer = pIn->GetSrting(pOut);
	if (Answer == "y" || Answer == "n")
	{
		pOut->PrintMessage("Sorry, but you cannot save any grid currently");
	}
	else
		pOut->PrintMessage("Sorry, but you cannot save any grid currently");
}