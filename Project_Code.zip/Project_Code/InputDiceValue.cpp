#include "InputDiceValue.h"
#include"Snake.h"
#include"Ladder.h"
#include "Grid.h"
#include "Player.h"

#include <time.h> // used to in srand to generate random numbers with different seed

InputDiceValue::InputDiceValue(ApplicationManager* pApp) : Action(pApp)
{
}

void InputDiceValue::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	pOut->PrintMessage("please enter a dice value between 1-6");
    DiceValue = pIn->GetInteger(pOut);
	//checking that the value entered is between 1 and 6
	if (DiceValue < 1 || DiceValue>6)
	{
		pOut->ClearStatusBar();
		return;
	}
	
	pOut->ClearStatusBar();

}

void InputDiceValue::Execute()
{


	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	ReadActionParameters();

	if (DiceValue < 1 || DiceValue>6)
	{
		pOut->ClearStatusBar();
		return;
	}

	if (!pGrid->GetEndGame()) {


		Player* PlayerPtr;
		PlayerPtr = pGrid->GetCurrentPlayer();
		PlayerPtr->Move(pGrid, DiceValue);
		pGrid->AdvanceCurrentPlayer();


	}
	

}
