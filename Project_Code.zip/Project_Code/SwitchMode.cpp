#include "SwitchMode.h"
#include"Player.h"
#include"NewGame.h"
#include<iostream>
SwitchMode::SwitchMode(ApplicationManager* pApp,int s) : Action(pApp)
{
	state = s;
	// Initializes the pManager pointer of Action with the passed pointer
}


void SwitchMode::ReadActionParameters()
{
	//Grid* pGrid2 = pManager->GetGrid();
	//Grid* pGrid = pManager->GetGrid();
	//Output* pOut = pGrid->GetOutput();
	//Input* pin = pGrid->GetInput();
	/*Player* pPlayer = pGrid->GetCurrentPlayer();
	pGrid2->AdvanceCurrentPlayer();
		Player *p2=pGrid2->GetCurrentPlayer();
	pOut->PrintMessage("are you sure you want to switch mode?");
	pin->GetCellClicked();
	pOut->ClearStatusBar();
	pin->GetSrting(pOut);
	if (pin->GetSrting(pOut) == "y")
	{

	if(pPlayer->GetWallet()>p2->GetWallet())
	{
		pOut->PrintMessage("player 1 won");
		pOut->ClearStatusBar();
	}
	}*/

}

void SwitchMode::Execute()
{
	//Grid* pGrid2 = pManager->GetGrid();
	//Grid* pGrid3 = pManager->GetGrid();
//	Grid* pGrid4 = pManager->GetGrid();
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pin = pGrid->GetInput();
	  Player* pPlayer = pGrid->GetCurrentPlayer();
	  Grid* pGrid2 = pManager->GetGrid();
	pGrid2->AdvanceCurrentPlayer();
		Player *p2=pGrid2->GetCurrentPlayer();
		Grid* pGrid3 = pManager->GetGrid();
		pGrid3->AdvanceCurrentPlayer();
		Player* p3 = pGrid3->GetCurrentPlayer();
		Grid* pGrid4 = pManager->GetGrid();
		pGrid4->AdvanceCurrentPlayer();
		 Player* p4 = pGrid4->GetCurrentPlayer();
		//pOut->PrintMessage("PLAYER num" + to_string(p4->GetNum()));
		//pOut->PrintMessage("PLAYER num" + to_string(p3->GetNum()));
		//pOut->PrintMessage("PLAYER num" + to_string(p2->GetNum()));
		//pOut->PrintMessage("PLAYER num" + to_string(pPlayer->GetNum()));
		

	if (state == 0)
	{
		pOut->PrintMessage("do you want to save grid?(y/n)");
		s = pin->GetSrting(pOut);
		if (s == "y")
		{
			pOut->ClearStatusBar();
			pGrid->AdvanceCurrentPlayer();
			pPlayer->SetPlayerToOrigin(pGrid);
			p2->SetPlayerToOrigin(pGrid2);
			p3->SetPlayerToOrigin(pGrid3);
			p4->SetPlayerToOrigin(pGrid4);
			pPlayer->SetWallet(100);
			p2->SetWallet(100);
			p3->SetWallet(100);
			p4->SetWallet(100);
			pPlayer->SetTurnCount(0);
			p2->SetTurnCount(0);
			p3->SetTurnCount(0);
			p4->SetTurnCount(0);
			
			pOut->CreatePlayModeToolBar();
		}
		else if (s == "n") 
		{
			pOut->ClearStatusBar();
			pGrid->AdvanceCurrentPlayer();
			pPlayer->SetPlayerToOrigin(pGrid);
			p2->SetPlayerToOrigin(pGrid2);
			p3->SetPlayerToOrigin(pGrid3);
			p4->SetPlayerToOrigin(pGrid4);
			pPlayer->SetWallet(100);
			p2->SetWallet(100);
			p3->SetWallet(100);
			p4->SetWallet(100);
			pPlayer->SetTurnCount(0);
			p2->SetTurnCount(0);
			p3->SetTurnCount(0);
			p4->SetTurnCount(0);
			pOut->CreatePlayModeToolBar();
		}
		else
		{
			pOut->ClearStatusBar();
			pOut->PrintMessage("try again and click on the switch button..  please write (y) or (n)");
			pin->GetCellClicked();
			pOut->ClearStatusBar();
			   
		}
	}
	else if(state==1 )
	{
		pOut->PrintMessage("are you sure you want to switch mode and end game?(y/n)");
	s=	pin->GetSrting(pOut);
	int s1 = pPlayer->GetWallet();int s2 = p2->GetWallet();int s3 = p3->GetWallet();int s4 = p4->GetWallet();
	
	int m3 = max(max(s1,s2),max(s3,s4));
	if (s == "y" )
	{
		pOut->ClearStatusBar();
		
		if (m3 == s1 )
		{
			pOut->PrintMessage("player "+to_string(pPlayer->GetNum())+" won "+ " with wallet value " + to_string(s1));
			//pOut->ClearStatusBar();
		}
		else if (m3 == s2 )
		{
			pOut->PrintMessage("player  "+to_string( p2->GetNum())+" won "+" with wallet value " + to_string(s2));
		}
		else if (m3 == s3 )
		{

			pOut->PrintMessage("player  "+to_string(p3->GetNum())+" won " + " with wallet value "+to_string(s3));
		}
		else if (m3 == s4 )
		{

			pOut->PrintMessage("player  "+to_string(p4->GetNum())+" won "+" with wallet value " + to_string(s4));
		}
		
		pPlayer->SetPlayerToOrigin(pGrid);
		p2->SetPlayerToOrigin(pGrid2);
		p3->SetPlayerToOrigin(pGrid3);
		p4->SetPlayerToOrigin(pGrid4);
		pPlayer->SetWallet(100);
		p2->SetWallet(100);
		p3->SetWallet(100);
		p4->SetWallet(100);
		pPlayer->SetTurnCount(0);
		p2->SetTurnCount(0);
		p3->SetTurnCount(0);
		p4->SetTurnCount(0);
	
			//pOut->ClearStatusBar();
			pOut->CreateDesignModeToolBar();
			pOut->ClearGridArea();
		}
	}
	else if (s == "n")
	{
		pOut->ClearStatusBar();
		pOut->CreateDesignModeToolBar();
	//	pOut->ClearStatusBar();
	}
	else
	{
		pOut->PrintMessage(" try again and click on the switch button... please write (y)or(n) ");
		pin->GetCellClicked();
		pOut->ClearStatusBar();
	}
}