#include "CoinSet.h"

#include"Output.h"
#include<iostream>
using namespace std;
#include"Grid.h"
#include"GameObject.h"


CoinSet::CoinSet(const CellPosition& pos) : GameObject(pos)
{
}
void CoinSet::SetAmount(int A)
{
	Amount = A;
}
int CoinSet::GetAmount()
{
	return Amount;
}
void CoinSet::Draw(Output* pOut) const
{
	pOut->DrawCoinSet(position);

}

void CoinSet::Apply(Grid* pGrid, Player* pPlayer)
{
	pGrid->PrintErrorMessage("You have reached CoinSet " + to_string(Amount) + ". Click to continue ...");
	pPlayer->SetWallet(pPlayer->GetWallet() + Amount);

}
void CoinSet::CopySetCoin(Grid* pGrid)
{
	pGrid->PrintErrorMessage(" coin cannot be copy");
}
void CoinSet::EditSetCoin(Grid* pGrid)
{
	pGrid->PrintErrorMessage(" coin cannot edited");
}
void CoinSet::CutSetCoin(Grid* pGrid)
{
	pGrid->PrintErrorMessage(" coin cannot be cut");
}
void CoinSet::PasteSetCoin(Grid* pGrid)
{
	pGrid->PrintErrorMessage(" coin cannot paste");
}
void CoinSet::ReadCoinSetParameters(Grid* pGrid)
{

}


CoinSet::~CoinSet()
{
}
