#pragma once
#include "Action.h"
class OfferOrAcceptMortgageOrReturn :public Action
{
	int state;
	Player* p;
public:
	OfferOrAcceptMortgageOrReturn(ApplicationManager* pApp,int);
	virtual void ReadActionParameters();
	virtual void Execute();
	~OfferOrAcceptMortgageOrReturn();

};


