#pragma once

#include "Action.h"

class InputDiceValue : public Action
{
	int DiceValue=0;
	// No parameters for this action

public:
	InputDiceValue(ApplicationManager* pApp);

	virtual void ReadActionParameters();

	virtual void Execute();

};

