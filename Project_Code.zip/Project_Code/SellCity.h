#pragma once
#include"Action.h"
class SellCity :public Action
{
	Player* p;
public:
	SellCity(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~SellCity();
};

