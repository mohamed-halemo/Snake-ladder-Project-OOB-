#pragma once
#include"GameObject.h"
#include "Player.h"

class CoinSet :public GameObject
{
protected:
	int Amount;
public:

	CoinSet(const CellPosition& pos);
	void SetAmount(int A);
	int GetAmount();

	virtual void Draw(Output* pOut)const;
	virtual void Apply(Grid* pGrid, Player* pPlayer) ;
	virtual void ReadCoinSetParameters(Grid* pGrid);
	virtual void CopySetCoin(Grid* pGrid);
	virtual void EditSetCoin(Grid* pGrid);
	virtual void CutSetCoin(Grid* pGrid);
	virtual void PasteSetCoin(Grid* pGrid);
	virtual ~CoinSet();
};
