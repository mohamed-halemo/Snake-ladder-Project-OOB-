#include "Card.h"


Card::Card(const CellPosition & pos) : GameObject(pos) // sets the cell position of the GameObject
{
}

void Card::SetCardNumber(int cnum)
{
	cardNumber = cnum; // needs validation
}

int Card::GetCardNumber()
{
	//if (cardNumber > 0 && cardNumber <= 14)
	return cardNumber;
}

void Card::Draw(Output* pOut) const
{

	///TODO: call the appropriate Ouput function that draws a cell containing the "cardNumber" in "position"
	pOut->DrawCell(position, cardNumber);

}


void Card::ReadCardParameters(Grid * pGrid)
{
	// we should not make it pure virtual because some Cards doesn't have parameters
	// and if we make it pure virtual, that will make those Cards abstract classes
}

void Card::Apply(Grid* pGrid, Player* pPlayer) 
{
	
	// The following line is to print the following message if a player reaches a card of any type

	pGrid->PrintErrorMessage("You have reached card " + to_string(cardNumber) + ". Click to continue ...");
}


//void Card::Save(ofstream& OutFile, TYPE CARD)
//{
	//OutFile << cardNumber << "\t" << GameObject::position.GetCellNum() << "\t";
//}

//void Card::Read(ifstream& Infile)
//{
//
//}
bool Card::Validate() {
	return true;
}

void Card::Edit(Grid* pGrid)
{
	pGrid->PrintErrorMessage(" This card cannot be edited");
}

void Card::CopyCard(Grid* pGrid)
{
	//pGrid->SetClipboard();
	
	pGrid->PrintErrorMessage(" Card cannot be copied");
}

void Card::CutCard(Grid* pGrid)
{
	pGrid->PrintErrorMessage("Card cannot be cut");
}

void Card::PasteCard(Grid* pGrid)
{
	pGrid->GetClipboard();
	pGrid->AddObjectToCell(pGrid->GetClipboard());
	pGrid->PrintErrorMessage("Card cannot be pasted");
}

void Card::SetWallet(int W)
{
	Wallet = W;
}
int Card::GetWallet()
{
	return Wallet;
}
void Card::SetObjectNum(int No)
{
	ObjNum = No;
}
int Card::GetObjNum()
{
	return ObjNum;
}
void Card::SetEvenOrOdd(bool val)
{
	EvenOrOdd = val;
}
bool Card::GetEvenOrOdd()
{
	return EvenOrOdd;
}
bool Card::GetIsBought()
{
	return IsBought;
}
void Card::SetIsBought(bool B)
{
	IsBought = B;
}
Player* Card::GetIsOwner()
{
	return Owner;
}
void Card::SetIsOwner(Player* p)
{
	Owner = p;
}
void Card::SetCityPrice(int P)
{
	CityPrice = P;
}
int Card::GetCityPrice()
{
	return CityPrice;
}

Card::~Card()
{
}
