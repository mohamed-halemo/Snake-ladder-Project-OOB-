#include "BackwardCard_3.h"
#include"Player.h"


BackwardCard_3::BackwardCard_3(const CellPosition& pos) : Card(pos) // set the cell position of the card
{

	cardNumber = 3; // set the inherited cardNumber data member with the card number (6 here)
}

BackwardCard_3::~BackwardCard_3(void)
{
}


void BackwardCard_3::ReadCardParameters(Grid* pGrid)
{


	/// Their is NO parameters to read from  the user

}
void BackwardCard_3::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer); // Calling Apply() of the base class Card to print the message that you reached this card number
	
	
	pGrid->AdvanceCurrentPlayer();
	Player* p2 = pGrid->GetCurrentPlayer();
	
	pGrid->AdvanceCurrentPlayer();
	Player* p3 = pGrid->GetCurrentPlayer();
	
	pGrid->AdvanceCurrentPlayer();
	Player* p4 = pGrid->GetCurrentPlayer();


	int DiceNum = pPlayer->GetLastRolledDice(); // getting the justRolledDiceNum which the current player will move


	//pPlayer->Move(pGrid, -DiceNum);

		

	(pGrid, p2); // Calling Apply() of the base class Card to print the message that you reached this card number
	if (p2->GetCell()->GetCellPosition().GetCellNum() - DiceNum > 0)

		p2->Move(pGrid, -DiceNum);// moving the  first other player backward to the same number of steps that  current player just rolled 
	else
		pGrid->UpdatePlayerCell(p2, 1);

	(pGrid, p3); // Calling Apply() of the base class Card to print the message that you reached this card number
	if (p3->GetCell()->GetCellPosition().GetCellNum() - DiceNum > 0)
	p3->Move(pGrid, -DiceNum);// moving the second other  player backward to the same number of steps that current player just rolled 
	else
		pGrid->UpdatePlayerCell(p3, 1);

	(pGrid, p4); // Calling Apply() of the base class Card to print the message that you reached this card number
	if (p4->GetCell()->GetCellPosition().GetCellNum() - DiceNum > 0)
	p4->Move(pGrid, -DiceNum);// moving the third other player backward to the same number of steps that current player just rolled 
	else
		pGrid->UpdatePlayerCell(p4, 1);

}
/*void BackwardCard_3::Save(ofstream& OutFile, TYPE CARD)
{
	Card::Save(OutFile, CARD);
	OutFile << endl;
}

void BackwardCard_3::Read(ifstream& Infile)
{

}*/
