#pragma once
#include "Card.h"

#include <iostream>
using namespace std;
#include <fstream> 

class Cairo : public Card
{
	static int CityPrice;
	static int Fees;
	static bool Exists;
	static bool Bought;
	static Player* cityOwner;
public:


	Cairo(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid); // Reads the parameters of Cairo which is: 



	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of Cairo on the passed Player
	bool GetIsBought();
	void SetIsBought(bool);
	Player* GetIsOwner();
	void SetIsOwner(Player*);
	void SetCityPrice(int);
	int GetCityPrice();
	virtual ~Cairo(); // A Virtual Destructor

};

