#include "PreventCard_4.h"
#include "Grid.h"
#include "ApplicationManager.h"
#include<fstream>
#include<iomanip>



PreventCard_4::PreventCard_4(const CellPosition& pos) :Card(pos)
{
	cardNumber = 4;
}
void PreventCard_4::ReadCardParameters(Grid* pGrid)
{
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

}
void PreventCard_4::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	//int x, y;
	//window *pW;
		//pW->GetMouseClick(x, y);
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("Click On The Player you want to prevent from rolling");
CellPosition clicked=	pIn->GetCellClicked();
Cell c(clicked);
//if (c.HasPlayer())
//{
	//pOut->PrintMessage("ok");
	//return c.HasPlayer()->Move(pGrid,0);
//}
//pGrid->UpdatePlayerCell(pPlayer, pPlayer->GetCell()->GetCellPosition());

	CellPosition C = c.GetCellPosition();
	pGrid->AdvanceCurrentPlayer();
	Cell* c1 = pPlayer->GetCell();
	CellPosition cP1 = c1->GetCellPosition();
	if (clicked.GetCellNum() == cP1.GetCellNum())
	{
		pPlayer->Move(pGrid, 0);
		pOut->PrintMessage("prevented player no" + to_string(pPlayer->GetNum()));
	}
	else
	{
		pGrid->AdvanceCurrentPlayer();
		Cell* c2 = pPlayer->GetCell();
		CellPosition cP2 = c2->GetCellPosition();
		if (clicked.GetCellNum() == cP2.GetCellNum())
		{
			pPlayer->Move(pGrid, 0);
			pOut->PrintMessage("prevented player no" + to_string(pPlayer->GetNum()));
		}
		else
			pGrid->AdvanceCurrentPlayer();
		Cell* c3 = pPlayer->GetCell();
		CellPosition cP3 = c3->GetCellPosition();
		if (clicked.GetCellNum() == cP3.GetCellNum())
		{
			pPlayer->Move(pGrid, 0);
			pOut->PrintMessage("prevented player no" + to_string(pPlayer->GetNum()));
		}

	}
}
	/*void PreventCard_4::Save(ofstream & OutFile, TYPE CARD)
	{
		Card::Save(OutFile, CARD);
		OutFile << endl;

	}
	void PreventCard_4::Read(ifstream & infile)
	{
	}
	*/









	PreventCard_4::~PreventCard_4()
	{
	}
