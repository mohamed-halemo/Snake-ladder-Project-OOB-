#include "TakeCityCard_12.h"
#include"Cell.h"
#include"Player.h"
#include"Alex.h"
#include"Hurghada.h"
#include"Aswan.h"
#include"Luxor.h"
#include"Cairo.h"



TakeCityCard_12::TakeCityCard_12(const CellPosition& pos) :Card(pos)
{
	cardNumber = 12;
}
void TakeCityCard_12::ReadCardParameters(Grid* pGrid)
{
}
void TakeCityCard_12::Apply(Grid* pGrid, Player* pPlayer)
{

	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	Card::Apply(pGrid, pPlayer);

	pPlayer = pGrid->GetCurrentPlayer();



	CellPosition First(1);
	Card AC(First);
	
	Card* AC2 = pGrid->GetNextCard(Card::GetPosition().GetCellNum()+First.GetCellNum());
	Card* AC3 = pGrid->GetNextCard(1);
	pOut->PrintMessage("Enter City Number you want to take ");
	int Answer = pIn->GetInteger(pOut);
	
	if (AC2)
	{
		if (Answer == 7 || Answer == 8 || Answer == 9 || Answer == 10 || Answer == 11)
		{
			if (AC2->GetCardNumber() >= 7 && AC2->GetCardNumber() <= 11)
			{
				AC2->SetIsBought(1);
				AC2->SetIsOwner(pPlayer);
				pOut->PrintMessage(" you took the city with number "+to_string(AC2->GetCardNumber()));
			}
			else
			pOut->PrintMessage(" There are no cities ");
		}
		else
			pOut->PrintMessage(" There are no cities ");

	}
	else
		pOut->PrintMessage(" There are no cities ");
	if (AC3)
	{
		if (Answer == 7 || Answer == 8 || Answer == 9 || Answer == 10 || Answer == 11)
		{
			if (AC3->GetCardNumber() >= 7 && AC3->GetCardNumber() <= 11)
			{
				AC3->SetIsBought(1);
				AC3->SetIsOwner(pPlayer);
				pOut->PrintMessage(" you took the city with number " + to_string(AC3->GetCardNumber()));
			}
			else
				pOut->PrintMessage(" There are no cities ");
		}
		else
			pOut->PrintMessage(" There are no cities ");

	}
	else
		pOut->PrintMessage(" There are no cities ");
}











	TakeCityCard_12::~TakeCityCard_12(void)
	{
	}
