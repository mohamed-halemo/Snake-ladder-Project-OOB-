#pragma once
#include"Card.h"
class FreezeCard_6 : public Card
{
private:

	bool isFrozen;
	int FrozenTurns;
	int OddOrEven;

public:
	FreezeCard_6(const CellPosition &pos); // A Constructor takes card position
	virtual void ReadCardParameters(Grid* pGrid); //Reads the parameyers of PreventCard_4 which is:
	virtual void Apply(Grid* pGrid, Player* pPlayer);
	void SetEvenOrOdd(bool );
	bool GetEvenOrOdd();
	//void Save(ofstream& OutFile, TYPE CARD);
	//void Read(ifstream& Infile);
	virtual~FreezeCard_6();// A Virtual Destructor
};

