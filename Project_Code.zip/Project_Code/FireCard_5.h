#pragma once
#include "Card.h"
class FireCard_5 : public Card
{

public:
	FireCard_5(const CellPosition& pos); // A Constructor takes card position
	virtual void ReadCardParameters(Grid* pGrid); // Reads the parameters of DecWalletCard_1 which is: walletAmount
	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of DecWalletCard_1 on the passed Player
//	void Save(ofstream& OutFile, TYPE CARD);
//	void Read(ifstream& Infile);



	 ~FireCard_5(); // A Virtual Destructor



};

