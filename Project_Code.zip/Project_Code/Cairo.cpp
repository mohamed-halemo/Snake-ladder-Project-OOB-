#include "Cairo.h"
#include <iostream>
using namespace std;
#include <fstream> 


bool Cairo::Exists = 0;
bool  Cairo::Bought = 0;
int  Cairo::CityPrice = 0;
int  Cairo::Fees = 0;
Player* Cairo::cityOwner = NULL;



Cairo::Cairo(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 7; // set the inherited cardNumber data member with the card number (7 here)

}


Cairo::~Cairo()
{
}


void Cairo::ReadCardParameters(Grid* pGrid)
{
	//Getting a Pointer to the Input / Output Interfaces from the Grid
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();

	//a Static data member to make sure that the parameters of cairo card has been entered once
	//The parameters of any City must be entered only at the first time the user adds this city
	if (Exists)
	{
		return;
	}

	//Reading an Integer from the user using the Input class and set the Price and the Fees parameters with it
	pOut->PrintMessage("New City: Enter the City Price to be paid by the cityOwner ...");
	int unValidatedPrice = pIn->GetInteger(pOut);

	//Forcing the User to enter a positive value for CityPrice
	while (unValidatedPrice < 0)
	{
		pOut->PrintMessage("the City Price must be positive, please Enter again its City Price ..");
		unValidatedPrice = pIn->GetInteger(pOut);

	}
	CityPrice = unValidatedPrice;


	//Reading an Integer from the user using the Input class and set the Price and the Fees parameters with it
	pOut->PrintMessage("Enter the City Fees to be paid by the passing player...");
	int unValidatedFees = pIn->GetInteger(pOut);


	//Forcing the User to enter a positive value for City Fees
	while (unValidatedFees < 0)
	{
		pOut->PrintMessage("the City Fees must be positive, please Enter again its City Fees ..");
		unValidatedFees = pIn->GetInteger(pOut);

	}
	Fees = unValidatedFees;
	Exists = 1;


	//Clearing the status bar
	pOut->ClearStatusBar();

}




void Cairo::Apply(Grid* pGrid, Player* pPlayer)
{
	//Calling Apply() of the base class Card to print the message that you reached this city number

	if ((pPlayer->getCountPrisonedTurns() == 0))
	{
		Card::Apply(pGrid, pPlayer);
	}
	//Getting a Pointer to the Input / Output Interfaces from the Grid
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();

	if (!Bought)
	{

		//checking if the player have enough money to buy this city

		if ((pPlayer->GetWallet()) >= CityPrice)
		{

			//Giving the player the option to either buy this city or skip it
			pOut->PrintMessage("You have reached Cairo City , city's Price= " + to_string(CityPrice) + " 'YES' to buy it or 'NO' to skip it ");

			string state = pIn->GetSrting(pOut);
			if (state == "YES" || state == "yes")
			{
				pPlayer->SetWallet((pPlayer->GetWallet()) - CityPrice);
				Bought = 1;
				cityOwner = pPlayer;
			}
			else
			{
				pGrid->PrintErrorMessage("Operation cancelled, you will regret not buying that city...Click to continue ");
			}

		}
		else
		{
			pGrid->PrintErrorMessage("Sorry, you don't have enough money to buy that city...Click to continue ");
		}
	}
	//checking if this city  has been bought by a player

	if (Bought)
	{
		if (cityOwner == pPlayer)
		{
			pGrid->PrintErrorMessage("You are in your bought city cell ...Click to continue ");
		}
		else if (cityOwner != pPlayer)
		{

			//taking the fees form the passing player's wallet and adding this fees to the cityOwner's wallet
			if ((pPlayer->GetWallet()) < Fees)
			{
				if ((pPlayer->getCountPrisonedTurns()) == 0)
				{
					pGrid->PrintErrorMessage("You have reached a bought cell, And You don't have enough money to pay " + to_string(Fees) + " Coins, you will be in your place prisoned till you have enough money...");
				}
				else
				{
					pGrid->PrintErrorMessage("Money is still not enough,you will remain in your place prisoned  ...Click to continue..");

				}

				pPlayer->IncrementCountPrisonedTurns();
				pPlayer->SetDeptedFees(Fees);
			}
			else
			{
				if ((pPlayer->getCountPrisonedTurns()) != 0)
				{
					pPlayer->SetWallet(((pPlayer->GetWallet()) - Fees));
					cityOwner->SetWallet(((cityOwner->GetWallet()) + Fees));

					pGrid->PrintErrorMessage("Finally you have enough Money to be move froom your place , Click to transfer money  ....");
					pPlayer->ResetCountPrisonedTurns();
					pPlayer->SetDeptedFees(0);
				}
				else
				{
					pGrid->PrintErrorMessage("You have reached a bought cell, you should pay to player" + to_string(cityOwner->getPlayerNum()) + " " + to_string(Fees) + " Coins, Click to tranfer money...");


					pPlayer->SetWallet((pPlayer->GetWallet()) - Fees);
					cityOwner->SetWallet((cityOwner->GetWallet()) + Fees);

				}
			}

		}
	}
}

void Cairo::SetIsBought(bool B)
{
	Bought = B;
}
bool Cairo::GetIsBought()
{
	return Bought;
}
Player* Cairo::GetIsOwner()
{
	return cityOwner;
}
void Cairo::SetIsOwner(Player* p)
{
	cityOwner = p;
}
void Cairo::SetCityPrice(int P)
{
	CityPrice = P;
}
int Cairo::GetCityPrice()
{
	return CityPrice;
}
