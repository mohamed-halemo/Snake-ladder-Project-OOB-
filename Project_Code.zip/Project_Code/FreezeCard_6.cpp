#include "FreezeCard_6.h"
#include"Cell.h"
#include"Player.h"



FreezeCard_6::FreezeCard_6(const CellPosition& pos) :Card(pos)
{
	cardNumber = 6;
}
void FreezeCard_6::ReadCardParameters(Grid* pGrid)
{
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("plase choose which cells to be frozen odd/even (for odd write 0 and for even 1)");
	isFrozen=pIn->GetInteger(pOut);
}
void FreezeCard_6::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);

	pGrid->AdvanceCurrentPlayer();
	Player* p2 = pGrid->GetCurrentPlayer();

	pGrid->AdvanceCurrentPlayer();
	Player* p3 = pGrid->GetCurrentPlayer();

	pGrid->AdvanceCurrentPlayer();
	Player* p4 = pGrid->GetCurrentPlayer();




	Cell* c2 = p2->GetCell();
	int cn2 = c2->GetCellPosition().GetCellNum();
   



	Cell* c3 = p3->GetCell();
	int cn3 = c3->GetCellPosition().GetCellNum();



	Cell* c4 = p4->GetCell();
	int cn4 = c4->GetCellPosition().GetCellNum();


	if (isFrozen == true)  //even
	{
		if (cn2 % 2 == 0 )
		{
			p2->SetZeroRoll();
		}
		 if (cn3 % 2 == 0)
		 {
			p3->SetZeroRoll();
		 }
	    if (cn4 % 2 == 0)
		{
			p4->SetZeroRoll();
		}
	}
	else
	{
		 if (cn2 % 3 == 0)
		{
			p2->SetZeroRoll();
		}
		if (cn3 % 3 == 0)
		{
			p3->SetZeroRoll();
		}
		if (cn4 % 3 == 0)
		{
			p4->SetZeroRoll();
		}


	}
}
void FreezeCard_6::SetEvenOrOdd(bool val)
{
	isFrozen = val;
}
bool FreezeCard_6::GetEvenOrOdd()
{
	return isFrozen;
}
/*void FreezeCard_6::Save(ofstream& OutFile, TYPE CARD)
{
	Card::Save(OutFile, CARD);
		OutFile << endl;

}
void FreezeCard_6::Read(ifstream& infile)
{
}*/



FreezeCard_6::~FreezeCard_6(void)
{
}
