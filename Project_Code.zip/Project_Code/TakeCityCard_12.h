#pragma once
#include "Card.h"
class TakeCityCard_12 :public Card
{
private:
	int CityNumber;
public:
	TakeCityCard_12(const CellPosition& pos);
	virtual void ReadCardParameters(Grid* pGrid);
	virtual void Apply(Grid* pGrid, Player* pPlayer);
	//	void Save(ofstream& OutFile, TYPE CARD);
	//	void Read(ifstream& Infile);

	
	virtual~TakeCityCard_12();
};

