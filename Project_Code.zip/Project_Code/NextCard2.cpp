#include "NextCard2.h"
#include"Ladder.h"
#include"Snake.h"
#include"CoinSet.h"
NextCard2::NextCard2(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 2; // set the inherited cardNumber data member with the card number (1 here)
}

NextCard2::~NextCard2(void)
{
}

void NextCard2::ReadCardParameters(Grid* pGrid)
{


	///TODO: Implement this function as mentioned in the guideline steps (numbered below) below


	// == Here are some guideline steps (numbered below) (numbered below) to implement this function ==


	// 1- Get a Pointer to the Input / Output Interfaces from the Grid

	// 2- Read an Integer from the user using the Input class and set the walletAmount parameter with it
	//    Don't forget to first print to a descriptive message to the user like:"New DecWalletCard_1: Enter its wallet amount ..."


	// [ Note ]:
	// In DecWalletCard_1, the only parameter of DecWalletCard_1 is the "walletAmount" value to decrease from player
	// Card parameters are the inputs you need to take from the user in the time of adding the Card in the grid
	// to be able to perform his Apply() action

	// 3- Clear the status bar
	Input* pIn = pGrid->GetInput();//
	Output* pOut = pGrid->GetOutput();//

	pOut->PrintMessage("New Card Two. Enter object number: ");//
	ObjNum = pIn->GetInteger(pOut);//
	CP=pIn->GetCellClicked();//
	pOut->ClearStatusBar();//


}
void NextCard2::SetObjectNum(int No)
{
	ObjNum = No;
}
int NextCard2::GetObjNum()
{
	return ObjNum;
}

void NextCard2::Apply(Grid* pGrid, Player* pPlayer)
{

	///TODO: Implement this function as mentioned in the guideline steps (numbered below) below


	// == Here are some guideline steps (numbered below) (numbered below) to implement this function ==

	// 1- Call Apply() of the base class Card to print the message that you reached this card number

	// 2- Decrement the wallet of pPlayer by the walletAmount data member of DecWalletCard_1
	Card::Apply(pGrid, pPlayer);//
	Cell* CC = pPlayer->GetCell();
	//for (int i = 0;i < NumHorizontalCells;i++)
	//{
	CellPosition Co = 0;
	Ladder* L = pGrid->GetNextLadder(pPlayer->GetCell()->GetCellPosition());
	Snake* S =  pGrid->GetNextSnake(pPlayer->GetCell()->GetCellPosition());
    Card* C = pGrid->GetNextCard(pPlayer->GetCell()->GetCellPosition());
	CoinSet* CS= pGrid->GetNextCoinSet(pPlayer->GetCell()->GetCellPosition());
	
	if (ObjNum == 1)
	{
		if (L)
		{

			pGrid->UpdatePlayerCell(pPlayer, L->GetPosition());
			pPlayer->Move(pGrid, 0);
		}
		else
		{
			L = pGrid->GetNextLadder(1);
			if (L)
			{
				pGrid->UpdatePlayerCell(pPlayer, L->GetPosition());
				pPlayer->Move(pGrid, 0);
			}

		}

	}
	else if (ObjNum == 2)
	{
		if (S)
		{
			pGrid->UpdatePlayerCell(pPlayer, S->GetPosition());
			pPlayer->Move(pGrid, 0);
		}
		else
		{
			S = pGrid->GetNextSnake(1);
			if (S)
			{
				pGrid->UpdatePlayerCell(pPlayer, S->GetPosition());
				pPlayer->Move(pGrid, 0);
			}

		}
	}
	else if (ObjNum == 3)
	{
		if (C )
		{
			pGrid->UpdatePlayerCell(pPlayer, C->GetPosition());
			pPlayer->Move(pGrid, 0);
		}
		else
		{
			C = pGrid->GetNextCard(1);
			if (C)
			{
				pGrid->UpdatePlayerCell(pPlayer, C->GetPosition());
				pPlayer->Move(pGrid, 0);
			}

		}
	}
	else if (ObjNum == 4)
	{
		if (CS)
		{
			pGrid->UpdatePlayerCell(pPlayer,CS->GetPosition() );
			pPlayer->Move(pGrid, 0);
		}
		else
		{
			CS = pGrid->GetNextCoinSet(1);
			if (CS)
			{
				pGrid->UpdatePlayerCell(pPlayer, CS->GetPosition());
				pPlayer->Move(pGrid, 0);
			}

		}
	}
}