#include "RollDiceAction.h"
#include"Snake.h"
#include"Ladder.h"
#include "Grid.h"
#include "Player.h"
#include"Card.h"
#include <time.h> // used to in srand to generate random numbers with different seed

RollDiceAction::RollDiceAction(ApplicationManager *pApp) : Action(pApp)
{
}

void RollDiceAction::ReadActionParameters()
{
	// no parameters to read from user
}

void RollDiceAction::Execute()
{
	// == Here are some guideline steps (numbered below) to implement this function ==

// 1- Check if the Game is ended (Use the GetEndGame() function of pGrid), if yes, make the appropriate action
	
	Grid* pGrid = pManager->GetGrid();
	if (!pGrid->GetEndGame()) {
		// -- If not ended, do the following --:

		// 2- Generate a random number from 1 to 6 --> This step is done for you
		srand((int)time(NULL)); // time is for different seed each run
		int diceNumber = 1 + rand() % 6; // from 1 to 6 --> should change seed

		// 3- Get the "current" player from pGrid
		
		Output* pOut = pGrid->GetOutput();
		Input* pIn = pGrid->GetInput();
		Player* PlayerPtr = pGrid->GetCurrentPlayer();
		// 4- Move the currentPlayer using function Move of class player

		PlayerPtr->Move(pGrid, diceNumber);
		
		
		// 5- Advance the current player number of pGrid
		pGrid->AdvanceCurrentPlayer();

		PlayerPtr->GetCell();
		CellPosition C = PlayerPtr->GetCell()->GetCellPosition();
		Cell c(C);
		if (c.HasLadder())
		{
			GameObject* G = c.HasLadder();
			Ladder* L = c.HasLadder();
			pOut->PrintMessage("you have reached a cell of a ladder ");
			pIn->GetCellClicked();
			L->Apply(pGrid, PlayerPtr);
		}
		if (c.HasSnake())
		{
			GameObject* G = c.HasSnake();
			Snake* S = c.HasSnake();
			pOut->PrintMessage("you have reached a cell of a snake ");
			pIn->GetCellClicked();
			S->Apply(pGrid, PlayerPtr);
		}

		if (c.HasCard())
		{
			GameObject* G = c.HasCard();
			Card* CC = c.HasCard();
			if (CC->GetCardNumber() == 7 || CC->GetCardNumber() == 8 || CC->GetCardNumber() == 9 || CC->GetCardNumber() == 10 || CC->GetCardNumber() == 11)
			{
				if (CC->GetIsBought())
				{
					pOut->PrintMessage("you have reached a cell of a monopoly bought city.click to continue ");
				}
				else
				{
					pOut->PrintMessage("you have reached a cell of a monopoly card.would you like to buy it?y/n");
				  string answer=	pIn->GetSrting(pOut);
				  if (answer == "y")
				  {
					  CC->Apply(pGrid,PlayerPtr);
				  }
				  else if (answer == "n")
				  {
					  return;
				  }
				  else
				  {
					  pOut->PrintMessage("you didnot give a correct  answer please write y or n");
				  }


				}
				pIn->GetCellClicked();
			}
			pOut->PrintMessage("you have reached a cell of a card. click to continue ");
			pIn->GetCellClicked();
			CC->Apply(pGrid, PlayerPtr);
		}
	}
	// NOTE: the above guidelines are the main ones but not a complete set (You may need to add more steps).

}

RollDiceAction::~RollDiceAction()
{
}
