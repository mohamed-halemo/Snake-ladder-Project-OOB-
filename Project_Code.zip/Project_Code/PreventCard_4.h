#pragma once
#include"Card.h"
class PreventCard_4 : public Card
{
public:
	PreventCard_4(const CellPosition& pos); // A Constructor takes card position
	virtual void ReadCardParameters(Grid* pGrid); //Reads the parameyers of PreventCard_4 which is:
	virtual void Apply(Grid* pGrid, Player* pPlayer);
	//void Save(ofstream& OutFile, TYPE CARD);
	//void Read(ifstream& Infile);
	virtual~PreventCard_4();// A Virtual Destructor
};

