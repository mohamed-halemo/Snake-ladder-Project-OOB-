#include "FireCard_5.h"



FireCard_5::FireCard_5(const CellPosition& pos) : Card(pos) // set the cell position of the card

{
	cardNumber = 5; // set the inherited cardNumber data member with the card number (5 here)
}

FireCard_5::~FireCard_5()
{
}


void FireCard_5::ReadCardParameters(Grid* pGrid)
{



}
void FireCard_5::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer); // Calling Apply() of the base class Card to print the message that you reached this card number


	pGrid->AdvanceCurrentPlayer();
	Player* p2 = pGrid->GetCurrentPlayer();

	pGrid->AdvanceCurrentPlayer();
	Player* p3 = pGrid->GetCurrentPlayer();

	pGrid->AdvanceCurrentPlayer();
	Player* p4 = pGrid->GetCurrentPlayer();

	Cell* c1 = pPlayer->GetCell();
	CellPosition cp1 = c1->GetCellPosition();
	int X1 = cp1.HCell();
	int Y1 = cp1.VCell();



	Cell* c2 = p2->GetCell();
	CellPosition cp2 = c2->GetCellPosition();
	int X2 = cp2.HCell();
	int Y2 = cp2.VCell();


	Cell* c3 = p3->GetCell();
	CellPosition cp3 = c3->GetCellPosition();
	int X3 = cp3.HCell();
	int Y3 = cp3.VCell();

	Cell* c4 = p4->GetCell();
	CellPosition cp4 = c4->GetCellPosition();
	int X4 = cp4.HCell();
	int Y4 = cp4.VCell();

	if (X2 == X1 || Y2 == Y1)
	{
		CellPosition pos(8, 0);
		pGrid->UpdatePlayerCell(p2, pos);
		int p2wallet = p2->GetWallet();
		int decp2 = p2wallet / 2;
		p2->SetWallet(decp2);

	}

	if (X3 == X1 || Y3 == Y1)
	{
		CellPosition pos(8, 0);
		pGrid->UpdatePlayerCell(p3, pos);
		int p3wallet = p3->GetWallet();
		int decp3 = p3wallet / 2;
		p3->SetWallet(decp3);
	}


	if (X4 == X1 || Y4 == Y1)
	{
		CellPosition pos(8, 0);
		pGrid->UpdatePlayerCell(p4, pos);
		int p4wallet = p4->GetWallet();
		int decp4 = p4wallet / 2;
		p2->SetWallet(decp4);

	}




}





