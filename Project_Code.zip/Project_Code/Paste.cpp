#include "Paste.h"
#include"Card.h"
#include"DecWalletCard_1.h"
#include"NextCard2.h"
#include"BackwardCard_3.h"
#include"CoinSet.h"
#include"PreventCard_4.h"
#include"FireCard_5.h"
#include"FreezeCard_6.h"
#include"Cairo.h"
#include"Luxor.h"
#include"Aswan.h"
#include"Alex.h"
#include"Hurghada.h"
PasteCardOrCoin::PasteCardOrCoin(ApplicationManager* pApp) :Action(pApp)
{

}

void PasteCardOrCoin::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();
	pOut->PrintMessage("Click on the destination cell for pasting");

}

void PasteCardOrCoin::Execute()
{
	ReadActionParameters();
	Grid* pGrid = pManager->GetGrid();
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();
	pasteing = pIn->GetCellClicked();
	
	
	//int CoinsAmount = ClipCoin;
	if (pGrid->GetClipboard())
	{
		ClipCard = pGrid->GetClipboard();
		int cNum = pGrid->GetClipboard()->GetCardNumber();
		Card* copiedCard;

		switch (cNum)
		{
		case 1:
		{
			DecWalletCard_1* C1 = (DecWalletCard_1*)ClipCard;
			copiedCard = new DecWalletCard_1(pasteing);
			copiedCard->SetCardNumber(1);
			copiedCard->SetWallet(ClipCard->GetWallet());
			break;
		}
		case 2:
		{
			NextCard2* C2 = (NextCard2*)ClipCard;
			copiedCard = new NextCard2(pasteing);
			copiedCard->SetCardNumber(2);
			copiedCard->SetObjectNum(ClipCard->GetObjNum());
			break;
		}
		case 3:
		{
			BackwardCard_3* C1 = (BackwardCard_3*)ClipCard;
			copiedCard = new BackwardCard_3(pasteing);
			copiedCard->SetCardNumber(3);
			break;
		}
		case 4:
		{
			PreventCard_4* C1 = (PreventCard_4*)ClipCard;
			copiedCard = new PreventCard_4(pasteing);
			copiedCard->SetCardNumber(4);
			break;
		}
		case 5:
		{
			FireCard_5* C1 = (FireCard_5*)ClipCard;
			copiedCard = new FireCard_5(pasteing);
			copiedCard->SetCardNumber(5);
			break;
		}
		case 6:
		{
			FreezeCard_6* C1 = (FreezeCard_6*)ClipCard;
			copiedCard = new FreezeCard_6(pasteing);
			copiedCard->SetCardNumber(6);
			copiedCard->SetEvenOrOdd(ClipCard->GetEvenOrOdd());
			break;
		}
		case 7:
		{
			Cairo* C1 = (Cairo*)ClipCard;
			copiedCard = new Cairo(pasteing);
			copiedCard->SetCardNumber(7);
			break;
		}
		case 8:
		{
			Alex* C1 = (Alex*)ClipCard;
			copiedCard = new Alex(pasteing);
			copiedCard->SetCardNumber(8);
			break;
		}
		case 9:
		{
			Aswan* C1 = (Aswan*)ClipCard;
			copiedCard = new Aswan(pasteing);
			copiedCard->SetCardNumber(9);
			break;
		}
		case 10:
		{
			Luxor* C1 = (Luxor*)ClipCard;
			copiedCard = new Luxor(pasteing);
			copiedCard->SetCardNumber(10);
			break;
		}
		case 11:
		{
			Hurghada* C1 = (Hurghada*)ClipCard;
			copiedCard = new Hurghada(pasteing);
			copiedCard->SetCardNumber(11);
			break;
		}
		case 12:
		{
			Hurghada* C1 = (Hurghada*)ClipCard;
			copiedCard = new Hurghada(pasteing);
			copiedCard->SetCardNumber(12);
			break;
		}
		}


		bool z = pGrid->AddObjectToCell(copiedCard);
	}
	else if (pGrid->GetClipCoin())
	{

		ClipCoin = pGrid->GetClipCoin();
		CoinSet* CopiedCoin;
		CopiedCoin = new CoinSet(pasteing);
		CopiedCoin->SetAmount(ClipCoin->GetAmount());
		bool z2 = pGrid->AddObjectToCell(CopiedCoin);
	}
	else
		pOut->PrintMessage("you didnot copy anything");
}

PasteCardOrCoin::~PasteCardOrCoin()
{
}

