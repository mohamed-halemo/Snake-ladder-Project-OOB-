#pragma once
#include"GameObject.h"
#include"Grid.h"
#include"ApplicationManager.h"
#include"Action.h"
class DeleteGameObject :public Action
{
	CellPosition Object;
public:
	DeleteGameObject(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};

