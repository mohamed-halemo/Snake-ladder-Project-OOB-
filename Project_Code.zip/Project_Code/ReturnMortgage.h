#pragma once
#include"Action.h"
class ReturnMortgage :public Action
{
	Player* p;
public:
	ReturnMortgage(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~ReturnMortgage();
};

