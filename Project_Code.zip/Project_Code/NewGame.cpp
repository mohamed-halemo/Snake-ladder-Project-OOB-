#include "NewGame.h"
#include "Player.h"
#include"ApplicationManager.h"
#include "Input.h"
#include "Output.h"
NewGame::NewGame(ApplicationManager* pApp) : Action(pApp)
{

}
void NewGame::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("Click To Start A New Game...");
	pIn->GetCellClicked();
	pOut->ClearStatusBar();
}

void NewGame::Execute()
{
	ReadActionParameters();
	

	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	Player* pPlayer = pGrid->GetCurrentPlayer();

	if (pPlayer->GetNum() == 1)
	{
		pGrid->AdvanceCurrentPlayer();
		pGrid->AdvanceCurrentPlayer();
		pGrid->AdvanceCurrentPlayer();
	}
	else if(pPlayer->GetNum() == 2)
	{
		pGrid->AdvanceCurrentPlayer();
		pGrid->AdvanceCurrentPlayer();
	}
	else if (pPlayer->GetNum() == 3)
	{
		
		pGrid->AdvanceCurrentPlayer();
	}

	CellPosition StartCell(1);
	for (int i = 0;i < 4;i++)
	{
		Player* pPlayer = pGrid->GetCurrentPlayer();

		pGrid->UpdatePlayerCell(pPlayer, StartCell);
		pPlayer->SetWallet(100);
		pPlayer->SetTurnCount(0);
		pGrid->AdvanceCurrentPlayer();

	}


}