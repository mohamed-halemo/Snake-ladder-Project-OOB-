#pragma once
#include "Action.h"
#include"Card.h"
#include"CellPosition.h"
class OpenGrid :public Action
{
public:
	OpenGrid(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~OpenGrid();






};

