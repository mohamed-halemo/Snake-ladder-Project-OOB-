#include "AddCoinSet.h"

#include "Input.h"
#include "Output.h"
#include "DecWalletCard_1.h"
#include"CoinSet.h"
AddCoinSet::AddCoinSet(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

AddCoinSet::~AddCoinSet()
{
}

void AddCoinSet::ReadActionParameters()
{

	///TODO: Implement this function as mentioned in the guideline steps (numbered below) below


	// == Here are some guideline steps (numbered below) to implement this function ==

	// 1- Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	// 2- Read the "cardNumber" parameter and set its data member
	pOut->PrintMessage("New CoinSet: Enter CoinSet Amount ...");
	Amount = pIn->GetInteger(pOut);
	// 3- Read the "cardPosition" parameter (its cell position) and set its data member
	pOut->PrintMessage("Click Cell to add CoinSet ...");
	CoinSetPosition = pIn->GetCellClicked();
	// 4- Make the needed validations on the read parameters
	if (!CoinSetPosition.IsValidCell())
	{
		Amount = 0;
		pOut->ClearStatusBar();
		return;
	}
	// 5- Clear status bar
	pOut->ClearStatusBar();
}

void AddCoinSet::Execute()
{


	///TODO: Implement this function as mentioned in the guideline steps (numbered below) below


	// == Here are some guideline steps (numbered below) to implement this function ==

	// 1- The first line of any Action Execution is to read its parameter first
	ReadActionParameters();
	// 2- Switch case on cardNumber data member and create the appropriate card object type
	/*CoinSet* pCoin = NULL; // will point to the card object type
	switch (Amount)
	{
	case 1:
		pCoin = new CoinSet(CoinSetPosition);
		break;

		// A- Add the remaining cases

	}*/
	CoinSet* C ;
	C = new CoinSet(CoinSetPosition);
	
	// 3- if pCard is correctly set in the switch case (i.e. if pCard is pointing to an object -- NOT NULL)
//	if (pCoin)
	//{
		// A- We get a pointer to the Grid from the ApplicationManager
		Grid* pGrid = pManager->GetGrid();
		C->SetAmount(Amount);
		// B- Make the "pCard" reads its card parameters: ReadCardParameters(), It is virtual and depends on the card type
		C->ReadCoinSetParameters(pGrid);
		// C- Add the card object to the GameObject of its Cell:
		//pGrid->AddObjectToCell(C);
		// D- if the GameObject cannot be added in the Cell, Print the appropriate error message on statusbar
		if (pGrid->AddObjectToCell(C))
		{ }
		else
			pGrid->PrintErrorMessage("The CoinSet Cannot Be Added In The Cell");
	//}

	// Here, the card is created and added to the GameObject of its Cell, so we finished executing the AddCardAction

}
