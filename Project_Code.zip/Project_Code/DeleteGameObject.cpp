#include "DeleteGameObject.h"
#include "Input.h"
#include "Output.h"
#include"Grid.h"
#include"Action.h"
DeleteGameObject::DeleteGameObject(ApplicationManager* pApp) :Action(pApp)
{

}
void DeleteGameObject::ReadActionParameters()
{
	
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("click on the object you want to delete ");
	Object = pIn->GetCellClicked();    //getting the position of the cell we will delete the object on to use removeobjectfromcell function

}
void DeleteGameObject::Execute()
{
	ReadActionParameters();

	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	
	pGrid->RemoveObjectFromCell(Object);

	pOut->PrintMessage("Deleted");

	pOut->ClearStatusBar();
}