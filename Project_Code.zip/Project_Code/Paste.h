#pragma once
#include "Action.h"
#include"Card.h"
class PasteCardOrCoin :public Action
{

	Card* ClipCard;
	CoinSet* ClipCoin;
	CellPosition pasteing;
public:
	PasteCardOrCoin(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~PasteCardOrCoin();

};