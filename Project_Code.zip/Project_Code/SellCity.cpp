#include "SellCity.h"
#include "ReturnMortgage.h"
#include "OfferOrAcceptMortgage.h"
#include"Grid.h"
#include"Player.h"
#include"Alex.h"
#include"Aswan.h"
#include"Luxor.h"
#include"Hurghada.h"
#include"Cairo.h"
SellCity::SellCity(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

SellCity::~SellCity()
{
}

void SellCity::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();









	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void SellCity::Execute()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	p = pGrid->GetCurrentPlayer();
	CellPosition First(1);
	Card AC(First);

	Card* AC2 = pGrid->GetNextCard(First);
	if(AC2)
	{
		if (AC2->GetCardNumber() == 7 || AC2->GetCardNumber() == 8 || AC2->GetCardNumber() == 9 || AC2->GetCardNumber() == 10 || AC2->GetCardNumber() == 11)
		{
			if (AC2->GetIsBought())
			{
				pOut->PrintMessage("now you can sell one or more of the cities that you own enter city or the card number " + to_string(AC2->GetCardNumber()) + " is your city number write it's number to sell it ...");
				int Answer = pIn->GetInteger(pOut);
				if (Answer >= 7 && Answer <= 11)
				{
					p = AC2->GetIsOwner();
					p->SetWallet(p->GetWallet() + AC2->GetCityPrice() * 0.9);
					AC2->SetIsBought(0);

				}
				else
				{
					pOut->PrintMessage("you didnot enter the right number try again" + to_string(AC2->GetCardNumber()) + " Is a number of a city you own ");
				}
			}
		}
		else
		{
			pOut->PrintMessage("You have got no cities to sell");
		}
		pOut->ClearStatusBar();
		
	}

	else
	{
		pOut->PrintMessage("You have got no cities to sell");
	}
	

	
	



}

