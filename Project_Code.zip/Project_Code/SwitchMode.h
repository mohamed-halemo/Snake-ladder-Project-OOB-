#pragma once
#include"Action.h"
#include"Grid.h"
#include"Input.h"
#include"Output.h"
#include"ApplicationManager.h"
class SwitchMode:public Action
{
	int state;
	
	string s;
	

	public:
		SwitchMode(ApplicationManager* pApp,int);

		 void ReadActionParameters();
         void Execute();

};

