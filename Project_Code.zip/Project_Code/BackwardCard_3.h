#pragma once
#include "Card.h"


class BackwardCard_3 : public Card
{

public:
	BackwardCard_3(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid); // Reads the parameters of BackwardCard_3 which is: 

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of BackwardCard_3 on the other Players
	//void Save(ofstream& OutFile, TYPE CARD);
	//void Read(ifstream& Infile);
	virtual ~BackwardCard_3(); // A Virtual Destructor


};

