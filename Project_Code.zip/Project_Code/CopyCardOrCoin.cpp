#include "CopyCardOrCoin.h"
#include"DecWalletCard_1.h"
#include"Card.h"
#include"Cell.h"
#include"CellPosition.h"
#include"Grid.h"
#include"GameObject.h"
#include"AddCardAction.h"
CopyCardOrCoin::CopyCardOrCoin(ApplicationManager *pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

CopyCardOrCoin::~CopyCardOrCoin()
{
}

void CopyCardOrCoin::ReadActionParameters()
{	
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	


    

	

	

	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void CopyCardOrCoin::Execute()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	
	pOut->PrintMessage("Copy Card Or Coin: Click on source cell");
	
	Obj = pIn->GetCellClicked();
	CoinSet* CS = pGrid->GetNextCoinSet(Obj);
	Card* C= pGrid->GetNextCard(Obj);
	
	if(C)
	{
		pOut->PrintMessage("Copied Card");
		pGrid->SetClipboard(C);
	}
	else if(CS)
	{
		pOut->PrintMessage("Copied Coin");
		pGrid->SetClipCoin(CS);
	}
	else
	pGrid->PrintErrorMessage("Error You didnot click on a Card Or Coin,Click to continue");
	pGrid->GetOutput()->ClearStatusBar();
}

