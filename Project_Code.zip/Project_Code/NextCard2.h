#pragma once
#include "Card.h"
class NextCard2 : public Card
{
	// DecWalletCard_1 Parameters:
	int ObjNum; // the number of the cell that has an object
	CellPosition CP;	
public:
	NextCard2(const CellPosition& pos); // A Constructor takes card position
	void SetObjectNum(int);
	 int GetObjNum();
	virtual void ReadCardParameters(Grid* pGrid); // Reads the parameters of DecWalletCard_1 which is: walletAmount
	 void SetObjectNum();
	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of DecWalletCard_1 on the passed Player
	//virtual bool Validate();
	//virtual void Edit(Grid* pGrid);
	//virtual void CopyCard(Grid* pGrid);
	//virtual void CutCard(Grid* pGrid);
	//virtual void PasteCard(Grid* pGrid);              // by decrementing the player's wallet by the walletAmount data member

	virtual ~NextCard2(); // A Virtual Destructor
};




