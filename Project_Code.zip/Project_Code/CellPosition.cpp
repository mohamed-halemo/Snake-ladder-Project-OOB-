#include "CellPosition.h"
#include "UI_Info.h"

CellPosition::CellPosition () 
{
	// (-1) indicating an invalid cell (uninitialized by the user)
	vCell = -1; 
	hCell = -1; 
}

CellPosition::CellPosition (int v, int h)
{ 
	// (-1) indicating an invalid cell (uninitialized by the user)
	vCell = -1; 
	hCell = -1; 

	SetVCell(v);
	SetHCell(h);
}

CellPosition::CellPosition (int cellNum)
{
	(*this) = GetCellPositionFromNum(cellNum); // the function call with build a cell position (vCell and hCell)
												// from the passed (cellNum)
												// (*this) = ... --> this will copy the returned (vCell and hCell)
												//                   to the data members (vCell and hCell)
}

bool CellPosition::SetVCell(int v) 
{

	if (v <= (NumVerticalCells - 1) && v >= 0)
	{
		vCell = v;
		return true;
	}
	else
	{
		return false;
	} // this line sould be changed with your implementation


}

bool CellPosition::SetHCell(int h) 
{
	if (h < NumHorizontalCells && h >= 0)
	{
		hCell = h;
		return true;
	}
	else
	{
		return false;
	} // this line sould be changed with your implementation

}

int CellPosition::VCell() const 
{
	return vCell;
}

int CellPosition::HCell() const 
{
	return hCell;
}

bool CellPosition::IsValidCell() const 
{
	if ((hCell >= 0 && hCell < NumHorizontalCells) && (vCell >= 0 && vCell <= (NumVerticalCells - 1)))
		return true;
	else
		return false;

	// this line sould be changed with your implementation
}

int CellPosition::GetCellNum() const
{
	return GetCellNumFromPosition(*this); // (*this) is the calling object of GetCellNum
										  // which means the object of the current data members (vCell and hCell)
}

int CellPosition::GetCellNumFromPosition(const CellPosition & cellPosition)
{

    int v = (NumVerticalCells - 1) - cellPosition.vCell;
	int h = cellPosition.hCell;
	int cellnum = 1 + (v * NumHorizontalCells + h * 1);
	return cellnum;

	// this line should be changed with your implementation
}

CellPosition CellPosition::GetCellPositionFromNum(int cellNum)
{
	CellPosition position;
	int V=-1;
	int H=-1;
	if (cellNum >= 1 && cellNum <= 99)
	{



		for (int endrow = 0; endrow <= 88; endrow = endrow + NumHorizontalCells)
		{
			if (cellNum > endrow&& cellNum <= endrow + NumHorizontalCells)
			{
				V = (NumVerticalCells - 1) - (endrow / NumHorizontalCells);
				break;
			}

		}
	}

	position.SetVCell(V);
	H = cellNum - (((NumVerticalCells - 1) - V) * NumHorizontalCells) - 1;
	position.SetHCell(H);

	return position;
}

void CellPosition::AddCellNum (int addedNum)
{
	int newcellnumber = GetCellNum() + addedNum;
	GetCellPositionFromNum(newcellnumber);

}