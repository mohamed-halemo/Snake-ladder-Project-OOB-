#include "ReturnMortgage.h"
#include"Grid.h"
#include"Player.h"
#include"Alex.h"
#include"Aswan.h"
#include"Luxor.h"
#include"Hurghada.h"
#include"Cairo.h"
ReturnMortgage::ReturnMortgage(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

ReturnMortgage::~ReturnMortgage()
{
}

void ReturnMortgage::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();









	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void ReturnMortgage::Execute()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	pOut->PrintMessage("now you can return one or more of the cities that you mortgaged");
	p = pGrid->GetCurrentPlayer();

}

