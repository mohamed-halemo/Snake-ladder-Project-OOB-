#pragma once
#include "Action.h"
#include"Card.h"
#include"CellPosition.h"
class SaveGrid :public Action
{
public:
	SaveGrid(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~SaveGrid();






};

