#include "OfferOrAcceptMortgage.h"
#include"Grid.h"
#include"Player.h"
#include"Alex.h"
#include"Aswan.h"
#include"Luxor.h"
#include"Hurghada.h"
#include"Cairo.h"
OfferOrAcceptMortgageOrReturn::OfferOrAcceptMortgageOrReturn(ApplicationManager* pApp,int s) : Action(pApp)
{
	state = s;// Initializes the pManager pointer of Action with the passed pointer
}

OfferOrAcceptMortgageOrReturn::~OfferOrAcceptMortgageOrReturn()
{
}

void OfferOrAcceptMortgageOrReturn::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	








	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void OfferOrAcceptMortgageOrReturn::Execute()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	p = pGrid->GetCurrentPlayer();
	Grid* pGrid2 = pManager->GetGrid();
	pGrid2->AdvanceCurrentPlayer();
	Player* p2 = pGrid2->GetCurrentPlayer();
	CellPosition First(1);
	Card AC(First);

	Card* AC2 = pGrid->GetNextCard(First);
	/*Alex* AC ;
	if (AC->GetIsBought())
	{
		pOut->PrintMessage("now you can offer one or more of your cities for mortgage");
	}*/
	if (state == 0)
	{
		
		if (AC2)
		{
			if (AC2->GetCardNumber() == 7 || AC2->GetCardNumber() == 8 || AC2->GetCardNumber() == 9 || AC2->GetCardNumber() == 10 || AC2->GetCardNumber() == 11)
			{
				if (AC2->GetIsBought())
				{
					pOut->PrintMessage("Now you can offer any of your cities for mortgage please enter city number " + to_string(AC2->GetCardNumber()) + "  Is one of your cities number write it's number to offer it");
					int Answer = pIn->GetInteger(pOut);
					if (Answer >= 7 && Answer <= 11)
					{
						pOut->PrintMessage("Now you offered city no " + to_string(AC2->GetCardNumber()) + " for mortgagge");

					}
					else
					{
						pOut->PrintMessage("you didnot enter the right number try again " + to_string(AC2->GetCardNumber()) + "  Is a number of a city you own ");
					}
				}
				else
				{
					
				}
				pOut->ClearStatusBar();

			}
			pOut->ClearStatusBar();
			pOut->PrintMessage("For The Next Player Click On The Accept Mortgage Icon to Mortgage A city");
		}

		else
			pOut->PrintMessage("You have got no cities for mortgage");
		
	}
	if (state == 1)
	{
		pOut->PrintMessage("Now You Accepted Mortgage");
		if (AC2)
		{
			if (AC2->GetIsBought())
			{
				if (p = AC2->GetIsOwner())
				{
					p->SetWallet(p->GetWallet() + AC2->GetCityPrice() * 0.7);
					AC2->SetIsBought(0);
					
					p->SetWallet(p->GetWallet() + (0.7 * AC2->GetCityPrice()));
					p2->SetWallet(p2->GetWallet() - (0.7 * AC2->GetCityPrice()) );
					AC2->SetIsOwner(p2);
					AC2->SetIsBought(1);
					AC2->Apply(pGrid, p2);
				}
			}
		}
			else
				pOut->PrintMessage("There Is Nothing To Mortgage");
		
	}
	if (state == 2)
	{
		if (AC2)
		{


			if (AC2->GetIsBought())
			{
			  
				pOut->PrintMessage("Now You Returned Mortgage");
				p2->SetWallet(p2->GetWallet() - 0.7 * AC2->GetCityPrice());
				p->SetWallet(p->GetWallet() + 0.7 * AC2->GetCityPrice());
				AC2->SetIsBought(1);
				AC2->SetIsOwner(p);
				AC2->Apply(pGrid, p);
			}
		}
			else
				pOut->PrintMessage("There Is Nothing To Return");
		
	}
}

