#pragma once
#include "Card.h"

#include <iostream>
using namespace std;
#include <fstream> 

class Aswan : public Card
{

	static int CityPrice;
	static int Fees;
	static bool Exists;
	static bool Bought;
	static Player* cityOwner;
public:


	Aswan(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid); // Reads the parameters of Aswan which is: 



	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of Aswan on the passed Player
	bool GetIsBought();
	void SetIsBought(bool);
	Player* GetIsOwner();
	void SetIsOwner(Player*);
	void SetCityPrice(int);
	int GetCityPrice();
	virtual ~Aswan(); // A Virtual Destructor

};

