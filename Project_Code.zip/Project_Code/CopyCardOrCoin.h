#pragma once
#include "Action.h"
#include"Card.h"
#include"CellPosition.h"
class CopyCardOrCoin :public Action
{
	Card* copy;
	Cell* pCell;
	CellPosition Obj;
public:
	CopyCardOrCoin(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
	~CopyCardOrCoin();






};

