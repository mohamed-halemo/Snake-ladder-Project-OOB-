#include "CutCardOrCoin.h"
#include"DecWalletCard_1.h"
#include"Card.h"
#include"Cell.h"
#include"CellPosition.h"
#include"Grid.h"
#include"GameObject.h"
#include"AddCardAction.h"

CutCardOrCoin::CutCardOrCoin(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

CutCardOrCoin::~CutCardOrCoin()
{
}

void CutCardOrCoin::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();









	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void CutCardOrCoin::Execute()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	pOut->PrintMessage("Cut Card Or Coin: Click on source cell");

	Obj = pIn->GetCellClicked();
	CoinSet* CS = pGrid->GetNextCoinSet(Obj);
	Card* C = pGrid->GetNextCard(Obj);

	if (C)
	{
		pOut->PrintMessage("Cut Card");
		pGrid->SetClipboard(C);
	}
	else if (CS)
	{
		pOut->PrintMessage("Cut Coin");
		pGrid->SetClipCoin(CS);
	}
	else
		pGrid->PrintErrorMessage("Error You didnot click on a Card Or Coin,Click to continue");
	pGrid->RemoveObjectFromCell(Obj);
	pGrid->GetOutput()->ClearStatusBar();
}

